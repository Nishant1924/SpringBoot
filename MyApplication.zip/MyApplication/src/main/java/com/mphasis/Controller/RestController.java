/*
 * package com.mphasis.Controller;
 * 
 * import org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.web.bind.annotation.GetMapping; import
 * org.springframework.web.bind.annotation.RequestParam; import
 * com.mphasis.Model.User; import com.mphasis.Services.UserService;
 * 
 * 
 * 
 * @org.springframework.web.bind.annotation.RestController public class
 * RestController {
 * 
 * @Autowired private UserService userservice;
 * 
 * 
 * @GetMapping("/") public String hello() { return "Hello!!!!!!!"; }
 * 
 * 
 * 
 * @GetMapping("/saveuser") public String saveUser(@RequestParam String
 * firstname, @RequestParam String lastname, @RequestParam String
 * password,@RequestParam int age, @RequestParam String email) { User user =new
 * User(firstname,lastname,password,age,email); userservice.saveUser(user);
 * return "User Saved"; }
 * 
 * }
 */
