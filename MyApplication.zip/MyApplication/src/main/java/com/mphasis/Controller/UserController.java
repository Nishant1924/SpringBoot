package com.mphasis.Controller;

import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import com.mphasis.Model.Document;
import com.mphasis.Model.User;
import com.mphasis.Services.UserService;

@Controller
public class UserController {

	@Autowired
	UserService userService;

	@RequestMapping("/")
	public String welcome(HttpServletRequest request) {
		request.setAttribute("mode", "MODE_HOME");
		return "welcomepage";
	}

	@RequestMapping("/home")
	public String Home(HttpServletRequest request) {
		request.setAttribute("mode", "HOME");
		return "homepage";
	}

	@RequestMapping("/register")
	public String registration(HttpServletRequest request) {
		request.setAttribute("mode", "MODE_REGISTER");
		return "welcomepage";
	}

	@RequestMapping("/upload")
	public String upload(HttpServletRequest request) {
		request.setAttribute("mode", "MODE_UPLOAD");
		return "homepage";
	}

	@PostMapping("/save-user")
	public String registerUser(@ModelAttribute User user, BindingResult bindingResult, HttpServletRequest request) {
		userService.saveUser(user);
		request.setAttribute("mode", "MODE_HOME");
		return "welcomepage";
	}

	@PostMapping("/save-document")
	public String fileUpload(@ModelAttribute Document document, BindingResult bindingResult, MultipartFile documentfile,
			HttpServletRequest request) throws IOException {
		String documentName = document.getDocumentname();
		byte[] file = documentfile.getBytes();
		Document document1 = new Document(documentName, file);
		userService.saveDocument(document1);
		request.setAttribute("mode", "MODE_UPLOAD");
		return "homepage";
	}

	@RequestMapping("/login")
	public String login(HttpServletRequest request) {
		request.setAttribute("mode", "MODE_LOGIN");
		return "welcomepage";
	}

	@RequestMapping("/login-user")
	public String loginUser(@ModelAttribute User user, HttpServletRequest request) {
		if (userService.findByEmailAndPassword(user.getEmail(), user.getPassword()) != null) {
			request.setAttribute("mode", "MODE_LOGIN_HOME");
			return "homepage";
		} else {
			request.setAttribute("error", "Invalid Username or Password");
			request.setAttribute("mode", "MODE_LOGIN");
			return "welcomepage";

		}
	}

	@RequestMapping("/edit-user")
	public String editEmployeeById(HttpServletRequest request, @RequestParam int id) {
		User user = userService.getUserById(id);
		request.setAttribute("user", userService.updateUser(user));
		request.setAttribute("mode", "MODE_UPDATE");
		return "welcomepage";
	}

	@GetMapping("/show-users")
	public String showAllUsers(HttpServletRequest request) {
		request.setAttribute("users", userService.showAllUsers());
		request.setAttribute("mode", "ALL_USERS");
		return "welcomepage";
	}

	@RequestMapping("/delete-user")
	public String deleteUser(@RequestParam int id, HttpServletRequest request) {
		userService.deleteMyUser(id);
		request.setAttribute("users", userService.showAllUsers());
		request.setAttribute("mode", "ALL_USERS");
		return "welcomepage";
	}

}
