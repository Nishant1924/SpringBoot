package com.mphasis.Model;

import java.time.LocalDateTime;
import java.util.Arrays;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;

import org.hibernate.annotations.CreationTimestamp;

@Entity
public class Document {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@CreationTimestamp
	private LocalDateTime date;
	private String documentname;
	
	@Lob
	private byte[] documentfile;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public LocalDateTime getDate() {
		return date;
	}

	public void setDate(LocalDateTime date) {
		this.date = date;
	}

	public String getDocumentname() {
		return documentname;
	}

	public void setDocumentname(String documentname) {
		this.documentname = documentname;
	}

	public byte[] getDocumentfile() {
		return documentfile;
	}

	public void setDocumentfile(byte[] documentfile) {
		this.documentfile = documentfile;
	}

	@Override
	public String toString() {
		return "Document [id=" + id + ", date=" + date + ", documentname=" + documentname + ", documentfile="
				+ Arrays.toString(documentfile) + "]";
	}

	

	public Document(String documentname, byte[] documentfile) {
		super();
		this.documentname = documentname;
		this.documentfile = documentfile;
	}

	public Document() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
