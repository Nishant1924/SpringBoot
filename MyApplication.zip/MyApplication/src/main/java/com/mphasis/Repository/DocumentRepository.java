package com.mphasis.Repository;

import org.springframework.data.repository.CrudRepository;

import com.mphasis.Model.Document;

public interface DocumentRepository extends CrudRepository<Document, Long> {

}
