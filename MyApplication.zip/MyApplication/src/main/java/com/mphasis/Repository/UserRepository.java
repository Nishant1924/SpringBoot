package com.mphasis.Repository;



import org.springframework.data.repository.CrudRepository;

import com.mphasis.Model.User;

public interface UserRepository extends CrudRepository<User, Integer> {
	
	public User findByEmailAndPassword(String username, String password);
	
}
