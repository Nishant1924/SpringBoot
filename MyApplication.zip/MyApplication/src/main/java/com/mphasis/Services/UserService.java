package com.mphasis.Services;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.Model.Document;
import com.mphasis.Model.User;
import com.mphasis.Repository.DocumentRepository;
import com.mphasis.Repository.UserRepository;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class UserService {

	private final UserRepository userRepository;
	
	@Autowired
	private DocumentRepository documentRepository;

	public UserService(UserRepository userRepository) {
		super();
		this.userRepository = userRepository;
	}

	public void saveUser(User user) {
		userRepository.save(user);
	}

	/*
	 * public void saveDocument(Document document) { userRepository.save(document);
	 * }
	 */
	
	public void saveDocument(Document document) {
        try {
        	documentRepository.save(document);
        } catch (Exception e) {
        }
    }
	
	public User findByEmailAndPassword(String email, String password) {
		return userRepository.findByEmailAndPassword(email, password);
	}

	public List<User> showAllUsers() {
		List<User> users = new ArrayList<User>();
		for (User user : userRepository.findAll()) {
			users.add(user);
		}

		return users;
	}

	public void deleteMyUser(int id) {
		userRepository.deleteById(id);
	}

	/*
	 * public Optional<User> editUser(Integer id) { return
	 * userRepository.findById(id); }
	 */

	public User getUserById(Integer id) {
		Optional<User> user = userRepository.findById(id);
			return user.get();
	}

	public User updateUser(User user) {
		Optional<User> user1 = userRepository.findById(user.getId());
		if (user1.isPresent()) {
			User newUser = user1.get();
			newUser.setEmail(user.getEmail());
			newUser.setFirstName(user.getFirstName());
			newUser.setLastName(user.getLastName());
			newUser.setAge(user.getAge());
			newUser.setPassword(user.getPassword());
			newUser = userRepository.save(newUser);
		}
		return user;
	}
}
